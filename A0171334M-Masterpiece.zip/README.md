# CS5436-Task-B
Work done for CS5346 Information Visualisation Task B, Week 6  
By Lee Yu Cong A0171334M  
Email: E0200904@u.nus.edu  

Files in the repository:  
Raw Data -- Data before cleaning and preprocessing  
Report -- Word document of a short report  
Tableau Visualisation -- Tableau Workbook for the visualisation  
Trade -- Cleaned Data  
Visualisation -- Screenshot of Visualisation from Tableau Workbook  